import os

from flask import Flask


def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY="dev",
        DATABASE=os.path.join(app.instance_path, "moj.sqlite"),
    )

    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile("config.py", silent=True)
    else:
        # load the test config if passed in
        app.config.from_mapping(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    from . import db

    db.init_app(app)

    from . import auth

    app.register_blueprint(auth.bp)

    from . import blog

    app.register_blueprint(blog.bp)
    app.add_url_rule("/", endpoint="index")

    def get_joke_rating(joke_id):
        joke_ratings = (
            db.get_db()
            .execute(
                "SELECT rating FROM review WHERE joke_id = ?",
                (joke_id,),
            )
            .fetchall()
        )
        sum = count = 0

        for joke_rating in joke_ratings:
            sum += joke_rating[0]
            count += 1

        return sum / count if count >= 1 else 0

    def has_rated(user_id, joke_id):
        joke_review = (
            db.get_db()
            .execute(
                "SELECT rating FROM review WHERE joke_id = ? AND user_id = ?",
                (joke_id, user_id),
            )
            .fetchone()
        )

        return joke_review is not None

    def has_joke(user_id, joke_title):
        user_joke = (
            db.get_db()
            .execute(
                "SELECT j.id FROM joke j JOIN user u ON j.author_id = u.id"
                " WHERE author_id = ? AND title = ? ORDER BY created DESC",
                (user_id, joke_title),
            )
            .fetchone()
        )

        return user_joke is not None

    app.jinja_env.globals.update(get_joke_rating=get_joke_rating)
    app.jinja_env.globals.update(has_rated=has_rated)
    app.jinja_env.globals.update(has_joke=has_joke)

    return app
